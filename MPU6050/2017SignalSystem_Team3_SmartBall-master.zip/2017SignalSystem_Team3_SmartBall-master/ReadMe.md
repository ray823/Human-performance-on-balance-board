# 專案來源: 成大資訊--訊號與系統課程的第三組
  專案成員: `李東霖`,`張文瑋`,`江家銘`,`趙韓信`
## 題目: 
3a. 如何測量投球的速度。

3b. 如何測量球旋轉的轉速與角度。

## hackmd 筆記
[hackmd](https://hackmd.io/s/rJ1fTlNce)

## 程式碼參考：
[I2C-MPU6050-SOURECODE](https://github.com/jrowberg/i2cdevlib/tree/master/Arduino/MPU6050)
